# Weather Forecast App

A responsive weather app built with HTML, CSS and JavaScript.

## Features
- Search weather by city name
- Current temperature and weather condition
- Feels-like temperature, humidity and wind speed
- Responsive layout
- Loading and error messages

## Technologies
HTML, CSS, JavaScript, Open-Meteo Geocoding API and Forecast API.

## How to run
1. Open this folder in VS Code.
2. Open `index.html` in a browser, preferably using Live Server.
3. Enter a city name, such as Satna or Delhi.

An internet connection is required. No API key is needed.
