const weatherForm = document.getElementById("weatherForm");
const cityInput = document.getElementById("cityInput");
const message = document.getElementById("message");
const weatherCard = document.getElementById("weatherCard");

const descriptions = {
  0:"Clear sky",1:"Mainly clear",2:"Partly cloudy",3:"Overcast",
  45:"Fog",48:"Depositing rime fog",51:"Light drizzle",53:"Moderate drizzle",
  55:"Dense drizzle",61:"Slight rain",63:"Moderate rain",65:"Heavy rain",
  71:"Slight snow",73:"Moderate snow",75:"Heavy snow",80:"Rain showers",
  81:"Moderate rain showers",82:"Violent rain showers",95:"Thunderstorm"
};

weatherForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  const city = cityInput.value.trim();
  if (!city) return;

  message.textContent = "Loading weather...";
  weatherCard.classList.add("hidden");

  try {
    const geoUrl = `https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(city)}&count=1&language=en&format=json`;
    const geoResponse = await fetch(geoUrl);
    if (!geoResponse.ok) throw new Error("Could not search for this city.");
    const geoData = await geoResponse.json();

    if (!geoData.results || geoData.results.length === 0) {
      throw new Error("City not found. Check the spelling and try again.");
    }

    const place = geoData.results[0];
    const weatherUrl = `https://api.open-meteo.com/v1/forecast?latitude=${place.latitude}&longitude=${place.longitude}&current=temperature_2m,relative_humidity_2m,apparent_temperature,weather_code,wind_speed_10m&timezone=auto`;
    const weatherResponse = await fetch(weatherUrl);
    if (!weatherResponse.ok) throw new Error("Weather information is not available right now.");
    const data = await weatherResponse.json();
    const current = data.current;

    document.getElementById("cityName").textContent =
      `${place.name}${place.admin1 ? ", " + place.admin1 : ""}, ${place.country}`;
    document.getElementById("temperature").textContent = Math.round(current.temperature_2m);
    document.getElementById("condition").textContent =
      descriptions[current.weather_code] || "Weather information";
    document.getElementById("feelsLike").textContent = `${Math.round(current.apparent_temperature)} °C`;
    document.getElementById("humidity").textContent = `${current.relative_humidity_2m}%`;
    document.getElementById("wind").textContent = `${current.wind_speed_10m} km/h`;
    document.getElementById("updated").textContent = `Updated: ${current.time.replace("T", " ")}`;

    message.textContent = "";
    weatherCard.classList.remove("hidden");
  } catch (error) {
    message.textContent = error.message || "Something went wrong. Please try again.";
  }
});
